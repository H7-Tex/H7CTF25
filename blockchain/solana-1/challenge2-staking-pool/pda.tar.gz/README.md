# H7CTF 2025 - Staking Pool Challenge

## Challenge Information

**Category:** Blockchain Security / Solana  
**Difficulty:** Medium  
**Points:** 500

## Description

H7Corp has deployed an employee staking pool system on Solana. Employees can initialize pools, deposit SOL, and withdraw their funds using their organization name and employee ID.

The admin has already initialized a pool with 100 SOL. Your objective is to drain at least 50 SOL from the admin's pool.

## Connection

```bash
nc challenge.h7ctf.com 5001
```

## Source Files

- `src/lib.rs` - Core types and instruction definitions
- `src/processor.rs` - Instruction processors (Initialize, Stake, Withdraw)
- `src/entrypoint.rs` - Program entrypoint
- `Cargo.toml` - Project configuration

## Program Overview

### Instructions

**Initialize** - Create a new staking pool
- Parameters: `organization: String`, `employee_id: String`
- Accounts: `[pool_pda, authority, system_program]`
- Derives PDA from organization and employee ID

**Stake** - Deposit SOL into a pool  
- Parameters: `amount: u64`
- Accounts: `[pool_pda, user (signer)]`
- Transfers SOL from user to pool

**Withdraw** - Withdraw SOL from a pool
- Parameters: `amount: u64`  
- Accounts: `[pool_pda, user (signer)]`
- Transfers SOL from pool to user

### Pool Structure

```rust
pub struct StakingPool {
    pub organization: String,
    pub employee_id: String,
    pub total_staked: u64,
    pub is_admin: bool,
}
```

### PDA Derivation

Pool PDAs are derived using:
```rust
Pubkey::find_program_address(
    &[b"POOL", organization.as_bytes(), employee_id.as_bytes()],
    program_id,
)
```

## Challenge Setup

When you connect, you'll receive:
- Your user account address and private key
- 10 SOL starting balance
- The program ID
- Admin pool information (H7Corp / admin)

The admin pool contains **100 SOL**. You need to steal at least **50 SOL** to get the flag.

## Building

```bash
# Install Solana toolchain (if not installed)
sh -c "$(curl -sSfL https://release.solana.com/stable/install)"

# Build the program
cargo build-sbf

# Output: target/deploy/staking_pool.so
```

## Submitting Your Exploit

You'll need to create an exploit program that:
1. Compiles to a Solana `.so` file
2. Takes the accounts passed by the server
3. Drains at least 50 SOL from the admin pool

The server will:
1. Load your exploit program
2. Create an instruction with the necessary accounts
3. Execute your exploit
4. Check if you've stolen enough SOL
5. Return the flag if successful

## Tips

- Study the PDA derivation carefully
- Look at how seeds are combined
- Think about what makes a valid pool PDA
- Consider edge cases in string concatenation
- The vulnerability is NOT in the Rust code safety itself

## Flag Format

`H7CTF{...}`

Good luck, and happy hacking! 🚀
