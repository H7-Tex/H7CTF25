pub mod entrypoint;
pub mod processor;

use borsh::{BorshDeserialize, BorshSerialize};
use solana_program::{
    instruction::{AccountMeta, Instruction},
    pubkey::Pubkey,
    system_program,
};

#[derive(BorshSerialize, BorshDeserialize, Debug)]
pub enum StakingInstruction {
    Initialize {
        organization: String,
        employee_id: String,
    },
    Stake { amount: u64 },
    Withdraw { amount: u64 },
}

#[derive(BorshSerialize, BorshDeserialize, Debug)]
pub struct StakingPool {
    pub organization: String,
    pub employee_id: String,
    pub total_staked: u64,
    pub is_admin: bool,
}

pub fn get_pool_pda(program_id: &Pubkey, organization: &str, employee_id: &str) -> (Pubkey, u8) {
    Pubkey::find_program_address(
        &[
            b"POOL",
            organization.as_bytes(),
            employee_id.as_bytes(),
        ],
        program_id,
    )
}
